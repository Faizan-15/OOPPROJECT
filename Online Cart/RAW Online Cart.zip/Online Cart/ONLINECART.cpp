#include <iostream>
#include <fstream>
#include <string>
using namespace std;

// Maximum number of products and cart size
const int MAX_PRODUCTS = 100;
const int MAX_CART_SIZE = 10;

// Product class to manage product details
class Product {
private:
    int id;
    string name;
    double price;
    int quantity;

public:
    // Constructor
    Product(int id = 0, string name = "", double price = 0.0, int quantity = 0) 
        : id(id), name(name), price(price), quantity(quantity) {}

    // Getters
    int getId() const { return id; }
    string getName() const { return name; }
    double getPrice() const { return price; }
    int getQuantity() const { return quantity; }

    // Display product details
    void display() const {
        cout << "ID: " << id << ", Name: " << name << ", Price: $" << price << ", Quantity: " << quantity << endl;
    }

    // Save product to file
    void saveToFile(ofstream& outFile) const {
        outFile << id << "," << name << "," << price << "," << quantity << endl;
    }

    // Load product from file
    void loadFromFile(const string& line) {
        size_t pos = 0;
        string token;
        int field = 0;

        // Parse the line
        string tempLine = line; // Create a mutable copy of the line
        while ((pos = tempLine.find(',')) != string::npos) {
            token = tempLine.substr(0, pos);
            switch (field) {
                case 0: id = stoi(token); break;
                case 1: name = token; break;
                case 2: price = stod(token); break;
                case 3: quantity = stoi(token); break;
            }
            tempLine.erase(0, pos + 1);
            field++;
        }
    }
};

// ShoppingCart class to manage the shopping cart
class ShoppingCart {
private:
    Product cart[MAX_CART_SIZE];
    int cartSize;

public:
    ShoppingCart() : cartSize(0) {}

    // Add product to cart
    void addProduct(const Product& product) {
        if (cartSize < MAX_CART_SIZE) {
            cart[cartSize++] = product;
            cout << "Product added to cart." << endl;
        } else {
            cout << "Cart is full! Cannot add more products." << endl;
        }
    }

    // Remove product from cart by ID
    void removeProduct(int id) {
        for (int i = 0; i < cartSize; ++i) {
            if (cart[i].getId() == id) {
                for (int j = i; j < cartSize - 1; ++j) {
                    cart[j] = cart[j + 1]; // Shift products left
                }
                cartSize--;
                cout << "Product removed from cart." << endl;
                return;
            }
        }
        cout << "Product not found in cart." << endl;
    }

    // Display cart contents
    void displayCart() const {
        cout << "\nShopping Cart Contents:\n";
        for (int i = 0; i < cartSize; ++i) {
            cart[i].display();
        }
    }

    // Calculate total price
    double calculateTotal() const {
        double total = 0;
        for (int i = 0; i < cartSize; ++i) {
            total += cart[i].getPrice();
        }
        return total;
    }
};

// Inventory class to manage products
class Inventory {
private:
    Product products[MAX_PRODUCTS];
    int productCount;

public:
    Inventory() : productCount(0) {}

    // Add product to inventory
    void addProduct(int id, string name, double price, int quantity) {
        if (productCount < MAX_PRODUCTS) {
            products[productCount++] = Product(id, name, price, quantity);
        } else {
            cout << "Inventory is full! Cannot add more products." << endl;
        }
    }

    // Display all products
    void displayProducts() const {
        cout << "\nAvailable Products:\n";
        for (int i = 0; i < productCount; ++i) {
            products[i].display();
        }
    }

    // Find product by ID
    Product* findProduct(int id) {
        for (int i = 0; i < productCount; ++i) {
            if (products[i].getId() == id) {
                return &products[i];
            }
        }
        return nullptr;
    }

    // Save products to file
    void saveToFile(const string& filename) {
        ofstream outFile(filename);
        if (outFile.is_open()) {
            for (int i = 0; i < productCount; ++i) {
                products[i].saveToFile(outFile);
            }
            outFile.close();
            cout << "Products saved to file." << endl;
        } else {
            cout << "Error opening file for writing." << endl;
        }
    }

    // Load products from file
    void loadFromFile(const string& filename) {
        ifstream inFile(filename);
        if (inFile.is_open()) {
            string line;
            while (getline(inFile, line)) {
                Product product;
                product.loadFromFile(line);
                addProduct(product.getId(), product.getName(), product.getPrice(), product.getQuantity());
            }
            inFile.close();
            cout << "Products loaded from file." << endl;
        } else {
            cout << "No existing product file found. Starting with an empty inventory." << endl;
        }
    }
};

// Main function to run the shopping cart management system
int main() {
    Inventory inventory;
    ShoppingCart cart;

    // Load products from file if it exists
    inventory.loadFromFile("products.txt");

    int choice;
    do {
        cout << "\n========= Online Shopping Cart Management System =========\n";
        cout << "1. View Products\n";
        cout << "2. Add Product to Cart\n";
        cout << "3. Remove Product from Cart\n";
        cout << "4. View Cart\n";
        cout << "5. Checkout\n";
        cout << "6. Save Products to File\n";
        cout << "7. Exit\n";
        cout << "Enter your choice (1-7): ";
        cin >> choice;

        switch (choice) {
            case 1:
                inventory.displayProducts();
                break;
            case 2: {
                int id;
                cout << "Enter Product ID to add to cart: ";
                cin >> id;
                Product* product = inventory.findProduct(id);
                if (product) {
                    cart.addProduct(*product);
                } else {
                    cout << "Product not found." << endl;
                }
                break;
            }
            case 3: {
                int id;
                cout << "Enter Product ID to remove from cart: ";
                cin >> id;
                cart.removeProduct(id);
                break;
            }
            case 4:
                cart.displayCart();
                break;
            case 5:
                cout << "Total Amount: $" << cart.calculateTotal() << endl;
                cout << "Thank you for shopping!" << endl;
                break;
            case 6:
                inventory.saveToFile("products.txt");
                break;
            case 7:
                cout << "Exiting program..." << endl;
                break;
            default:
                cout << "Invalid option. Try again." << endl;
        }
    } while (choice != 7);

    return 0;
}
